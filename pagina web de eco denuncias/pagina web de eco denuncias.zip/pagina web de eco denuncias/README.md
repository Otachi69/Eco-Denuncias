# Eco Denuncias - Proyecto

## Información del equipo

- **Yojan Alejandro Ordoñez Pacheco**: Se encargó de **Listado de denuncias**, **Detalle denuncia** y **Búsqueda de denuncias**.
- **María del Pilar Rivera Rodríguez**: Se encargó de **Solicitar restablecer contraseña** y **Aprobación de solicitud de cambio**.
- **Daniel Santiago Dorado Muñoz**: Se encargó de **Inicio de sesión** y **Crear cuenta**.
- **Andrés Felipe Dorado Muñoz**: Se encargó de **Consultas**.
- **Miguel Ángel Mosquera Muñoz**: Se encargó de **Menú principal**.
- **Yeimer Emerson Muñoz Chanchi**: Se encargó de **Denuncias**.
- **Keiner Bastidas Narvaez**: Se encargó de **Listado de solicitudes** y **Solicitudes**.
- **Juliana Vargas Vidal**: Se encargó de **Listado de solicitudes** y **Solicitudes**.

## Descripción del Proyecto
Este proyecto es una plataforma para gestionar denuncias ambientales, donde los usuarios pueden registrar denuncias, hacer búsquedas y solicitar cambios en sus contraseñas. La aplicación incluye una interfaz de usuario para interactuar con los datos, además de un sistema de autenticación para la gestión de cuentas.